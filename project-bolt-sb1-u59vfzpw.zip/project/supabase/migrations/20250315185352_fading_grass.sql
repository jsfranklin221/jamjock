/*
  # Add Stripe-related functions and triggers

  1. New Functions
    - increment_daily_earnings: Updates daily stats with new earnings
    - handle_payment_success: Processes successful payments
    - handle_payment_failure: Handles failed payments

  2. Security
    - Functions are restricted to service role access
*/

-- Function to increment daily earnings
CREATE OR REPLACE FUNCTION increment_daily_earnings(amount_earned numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO daily_stats (date, earnings)
  VALUES (CURRENT_DATE, amount_earned)
  ON CONFLICT (date)
  DO UPDATE SET earnings = daily_stats.earnings + EXCLUDED.earnings;
END;
$$;

-- Function to handle successful payments
CREATE OR REPLACE FUNCTION handle_payment_success(song_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE songs
  SET 
    paid = true,
    status = 'processing'
  WHERE id = song_id;
END;
$$;

-- Function to handle failed payments
CREATE OR REPLACE FUNCTION handle_payment_failure(song_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE songs
  SET status = 'failed'
  WHERE id = song_id;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION increment_daily_earnings TO service_role;
GRANT EXECUTE ON FUNCTION handle_payment_success TO service_role;
GRANT EXECUTE ON FUNCTION handle_payment_failure TO service_role;