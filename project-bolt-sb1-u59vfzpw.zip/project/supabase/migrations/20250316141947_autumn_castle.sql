/*
  # Fix Storage Policies

  1. Changes
    - Update storage policies to allow public uploads
    - Fix backing tracks bucket permissions
    - Enable upsert for all buckets
*/

-- Update storage policies for voice samples
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can read backing tracks" ON storage.objects;
  DROP POLICY IF EXISTS "Public can upload backing tracks" ON storage.objects;

  -- Allow public uploads and reads for voice samples
  CREATE POLICY "Anyone can upload voice samples"
    ON storage.objects
    FOR INSERT
    TO public
    WITH CHECK (bucket_id = 'voice_samples');

  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'voice_samples');

  -- Allow public access to backing tracks
  CREATE POLICY "Public can read backing tracks"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'backing_tracks');

  CREATE POLICY "Public can upload backing tracks"
    ON storage.objects
    FOR INSERT
    TO public
    WITH CHECK (bucket_id = 'backing_tracks');
END $$;

-- Make backing_tracks bucket public
UPDATE storage.buckets
SET public = true
WHERE id = 'backing_tracks';