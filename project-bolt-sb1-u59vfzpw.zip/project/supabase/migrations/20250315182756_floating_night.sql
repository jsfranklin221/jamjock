/*
  # Fix database schema and policies

  1. Changes
    - Ensure share_url column exists with unique constraint
    - Make user_id optional
    - Update RLS policies for public access
    - Fix storage bucket policies

  2. Security
    - Enable RLS on songs table
    - Add policies for public access to shared songs
    - Update storage policies for voice samples and generated songs
*/

-- Make sure RLS is enabled
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- Ensure share_url exists and is unique
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' 
    AND column_name = 'share_url'
  ) THEN
    ALTER TABLE songs ADD COLUMN share_url text;
  END IF;
END $$;

-- Make user_id optional
ALTER TABLE songs ALTER COLUMN user_id DROP NOT NULL;

-- Recreate policies with proper checks
DROP POLICY IF EXISTS "Public can create songs" ON songs;
DROP POLICY IF EXISTS "Public can access shared songs" ON songs;
DROP POLICY IF EXISTS "Public can view paid songs" ON songs;

CREATE POLICY "Public can create songs"
  ON songs
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can access shared songs"
  ON songs
  FOR SELECT
  TO public
  USING (share_url IS NOT NULL);

CREATE POLICY "Public can view paid songs"
  ON songs
  FOR SELECT
  TO public
  USING (paid = true);

-- Update storage policies
DROP POLICY IF EXISTS "Public can upload voice samples" ON storage.objects;
DROP POLICY IF EXISTS "Public can read generated songs" ON storage.objects;

CREATE POLICY "Public can upload voice samples"
  ON storage.objects
  FOR INSERT
  TO public
  WITH CHECK (bucket_id = 'voice_samples');

CREATE POLICY "Public can read generated songs"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'generated_songs');