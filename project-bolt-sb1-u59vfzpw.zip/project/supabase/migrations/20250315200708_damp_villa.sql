/*
  # Fix Schema and Constraints

  1. Schema Updates
    - Drop and recreate songs table with proper constraints
    - Add required columns and proper types
    - Set up correct RLS policies

  2. Changes
    - Add proper PRIMARY KEY constraint
    - Add NOT NULL constraints where needed
    - Update RLS policies for better security
*/

-- Drop existing table and recreate with proper schema
DROP TABLE IF EXISTS public.songs CASCADE;

CREATE TABLE public.songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  title text NOT NULL,
  voice_sample_url text NOT NULL,
  preview_url text,
  full_song_url text,
  share_url text UNIQUE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  paid boolean NOT NULL DEFAULT false,
  stripe_price_id text
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON public.songs(user_id);
CREATE INDEX IF NOT EXISTS idx_songs_status ON public.songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON public.songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON public.songs(share_url);

-- Enable RLS
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies and create new ones
DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
DROP POLICY IF EXISTS "Users can create songs" ON public.songs;
DROP POLICY IF EXISTS "Users can update their own songs" ON public.songs;
DROP POLICY IF EXISTS "Public can access shared songs" ON public.songs;

-- Create new policies
CREATE POLICY "Public can view completed songs"
  ON public.songs
  FOR SELECT
  USING (status = 'completed');

CREATE POLICY "Public can access shared songs"
  ON public.songs
  FOR SELECT
  USING (share_url IS NOT NULL);

CREATE POLICY "Users can create songs"
  ON public.songs
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own songs"
  ON public.songs
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);