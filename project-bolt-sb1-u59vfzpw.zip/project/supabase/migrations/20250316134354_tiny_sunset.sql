/*
  # Fix Songs Schema and Policies

  1. Changes
    - Add user_id column to songs table
    - Update policies to allow users to view their own songs
    - Fix public access policies

  2. Security
    - Ensure users can only see their own songs in library
    - Maintain public access for shared songs
*/

-- Add user_id column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN user_id uuid REFERENCES auth.users(id);
  END IF;
END $$;

-- Create index for user_id if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON public.songs(user_id);

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can view songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can access shared songs" ON public.songs;
  DROP POLICY IF EXISTS "Users can view own songs" ON public.songs;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Users can view own songs"
  ON public.songs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Public can access shared songs"
  ON public.songs
  FOR SELECT
  TO public
  USING (id IS NOT NULL);

-- Update storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  
  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'voice_samples');
END $$;