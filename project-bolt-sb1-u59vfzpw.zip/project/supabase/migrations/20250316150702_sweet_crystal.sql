/*
  # Fix Library Access Issues

  1. Changes
    - Update RLS policies for songs table
    - Add index for user_id and paid status
    - Fix storage access policies
*/

-- Update songs table policies
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Users can view own songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can access songs" ON public.songs;

  -- Create new policies
  CREATE POLICY "Users can view own songs"
    ON public.songs
    FOR SELECT
    TO authenticated
    USING (
      user_id = auth.uid() OR
      id IN (
        SELECT s.id FROM public.songs s
        WHERE s.paid = true AND s.share_url IS NOT NULL
      )
    );

  CREATE POLICY "Public can access songs"
    ON public.songs
    FOR SELECT
    TO public
    USING (
      paid = true AND 
      share_url IS NOT NULL
    );
END $$;

-- Create composite index for user_id and paid status
CREATE INDEX IF NOT EXISTS idx_songs_user_paid ON public.songs(user_id, paid);

-- Update storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Public can access voice samples" ON storage.objects;
  
  CREATE POLICY "Public can access voice samples"
    ON storage.objects
    FOR ALL
    TO public
    USING (bucket_id = 'voice_samples')
    WITH CHECK (bucket_id = 'voice_samples');
END $$;

-- Add trigger to update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add trigger to songs table
DO $$ 
BEGIN
  DROP TRIGGER IF EXISTS set_songs_updated_at ON public.songs;
  
  CREATE TRIGGER set_songs_updated_at
    BEFORE UPDATE ON public.songs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
END $$;