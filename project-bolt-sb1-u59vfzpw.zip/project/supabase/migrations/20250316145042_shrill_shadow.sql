/*
  # Fix Storage Policies for Voice Samples

  1. Changes
    - Update storage policies to allow public access
    - Enable unrestricted uploads to voice_samples bucket
    - Fix RLS policy violations
*/

-- Drop existing policies to avoid conflicts
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can access voice samples" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy for unrestricted access to voice samples
CREATE POLICY "Public can access voice samples"
  ON storage.objects
  FOR ALL
  TO public
  USING (bucket_id = 'voice_samples')
  WITH CHECK (bucket_id = 'voice_samples');

-- Ensure voice_samples bucket exists and is public
UPDATE storage.buckets
SET public = true
WHERE id = 'voice_samples';

-- Create index for voice sample URLs if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_songs_voice_sample ON public.songs(voice_sample_url);
CREATE INDEX IF NOT EXISTS idx_songs_preview_url ON public.songs(preview_url);