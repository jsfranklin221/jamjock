/*
  # Complete Database Setup

  1. Storage
    - Create voice_samples bucket if not exists
    - Set up storage policies for secure access

  2. Tables
    - users table with authentication integration
    - songs table with all necessary columns
    - daily_stats for tracking usage
    - payments for handling transactions

  3. Security
    - Enable RLS on all tables
    - Set up appropriate access policies
*/

-- Create storage bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'voice_samples'
  ) THEN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('voice_samples', 'voice_samples', false);
  END IF;
END $$;

-- Set up storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload voice samples" ON storage.objects;

  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'voice_samples');

  CREATE POLICY "Authenticated users can upload voice samples"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'voice_samples' AND
      auth.role() = 'authenticated'
    );
END $$;

-- Create users table
CREATE TABLE IF NOT EXISTS public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text NOT NULL,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  stripe_customer_id text
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can read own data" ON public.users;
  CREATE POLICY "Users can read own data"
    ON public.users
    FOR SELECT
    USING (auth.uid() = id);
END $$;

-- Create songs table
CREATE TABLE IF NOT EXISTS public.songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id),
  title text NOT NULL,
  voice_sample_url text,
  preview_url text,
  full_song_url text,
  share_url text UNIQUE,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  paid boolean DEFAULT false,
  stripe_price_id text
);

ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  DROP POLICY IF EXISTS "Users can create songs" ON public.songs;
  DROP POLICY IF EXISTS "Users can update their own songs" ON public.songs;

  CREATE POLICY "Public can view completed songs"
    ON public.songs
    FOR SELECT
    USING (status = 'completed');

  CREATE POLICY "Users can create songs"
    ON public.songs
    FOR INSERT
    WITH CHECK (true);

  CREATE POLICY "Users can update their own songs"
    ON public.songs
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);
END $$;

-- Create daily_stats table
CREATE TABLE IF NOT EXISTS public.daily_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE DEFAULT CURRENT_DATE,
  generations integer DEFAULT 0,
  earnings numeric(10,2) DEFAULT 0,
  api_costs numeric(10,2) DEFAULT 0
);

ALTER TABLE public.daily_stats ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS "Only admins can access stats" ON public.daily_stats;
  CREATE POLICY "Only admins can access stats"
    ON public.daily_stats
    FOR ALL
    USING (
      EXISTS (
        SELECT 1 FROM users
        WHERE users.id = auth.uid()
        AND users.is_admin = true
      )
    );
END $$;

-- Create payments table
CREATE TABLE IF NOT EXISTS public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id uuid REFERENCES public.songs(id),
  user_id uuid REFERENCES auth.users(id),
  amount integer NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  stripe_session_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can view their own payments" ON public.payments;
  DROP POLICY IF EXISTS "Users can insert their own payments" ON public.payments;

  CREATE POLICY "Users can view their own payments"
    ON public.payments
    FOR SELECT
    USING (auth.uid() = user_id);

  CREATE POLICY "Users can insert their own payments"
    ON public.payments
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON public.songs(user_id);
CREATE INDEX IF NOT EXISTS idx_songs_status ON public.songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON public.songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON public.songs(share_url);
CREATE INDEX IF NOT EXISTS idx_daily_stats_date ON public.daily_stats(date);