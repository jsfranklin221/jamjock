/*
  # Storage Policies and Schema Updates

  1. Storage Policies
    - Update policies for existing voice_samples bucket
    - Enable secure access controls

  2. Schema Updates
    - Add preview_url and voice_sample_url columns to songs table
    - Set up RLS policies for proper access control
*/

-- Set up storage policies for voice_samples bucket
DO $$
BEGIN
  -- Drop existing policies first to avoid conflicts
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload voice samples" ON storage.objects;

  -- Create new policies
  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'voice_samples');

  CREATE POLICY "Authenticated users can upload voice samples"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'voice_samples' AND
      auth.role() = 'authenticated'
    );
END $$;

-- Update songs table
DO $$
BEGIN
  -- Add columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'preview_url'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN preview_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'voice_sample_url'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN voice_sample_url text;
  END IF;
END $$;

-- Enable RLS on songs table if not already enabled
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate them
DO $$
BEGIN
  -- Public view policy
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  CREATE POLICY "Public can view completed songs"
    ON public.songs
    FOR SELECT
    USING (status = 'completed');

  -- Insert policy
  DROP POLICY IF EXISTS "Users can create songs" ON public.songs;
  CREATE POLICY "Users can create songs"
    ON public.songs
    FOR INSERT
    WITH CHECK (true);

  -- Update policy
  DROP POLICY IF EXISTS "Users can update their own songs" ON public.songs;
  CREATE POLICY "Users can update their own songs"
    ON public.songs
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);
END $$;