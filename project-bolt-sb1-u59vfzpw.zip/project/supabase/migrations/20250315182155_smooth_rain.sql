/*
  # Initial Database Schema Setup

  1. New Tables
    - `users`
      - `id` (uuid, primary key) - Links to auth.users
      - `email` (text, unique)
      - `is_admin` (boolean)
      - `created_at` (timestamp)
      - `stripe_customer_id` (text, nullable)
    
    - `songs`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `title` (text)
      - `voice_sample_url` (text)
      - `preview_url` (text, nullable)
      - `full_song_url` (text, nullable)
      - `status` (enum: pending, processing, completed, failed)
      - `created_at` (timestamp)
      - `paid` (boolean)
      - `stripe_price_id` (text, nullable)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add public access policies for shared content

  3. Storage
    - Create buckets for voice samples and generated songs
    - Set up appropriate access policies
*/

-- Create song status enum if it doesn't exist
DO $$ 
BEGIN
  CREATE TYPE song_status AS ENUM ('pending', 'processing', 'completed', 'failed');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  stripe_customer_id text
);

-- Create songs table
CREATE TABLE IF NOT EXISTS songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  title text NOT NULL,
  voice_sample_url text NOT NULL,
  preview_url text,
  full_song_url text,
  status song_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  paid boolean DEFAULT false,
  stripe_price_id text
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read own data" ON users;
  DROP POLICY IF EXISTS "Users can read own songs" ON songs;
  DROP POLICY IF EXISTS "Users can create songs" ON songs;
  DROP POLICY IF EXISTS "Public can view paid songs" ON songs;
  DROP POLICY IF EXISTS "Authenticated users can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can read generated songs" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Users table policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Songs table policies
CREATE POLICY "Users can read own songs"
  ON songs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create songs"
  ON songs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Public can view paid songs"
  ON songs
  FOR SELECT
  TO public
  USING (paid = true);

-- Create storage buckets
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES 
    ('voice_samples', 'voice_samples', false),
    ('generated_songs', 'generated_songs', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Storage policies
CREATE POLICY "Authenticated users can upload voice samples"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'voice_samples');

CREATE POLICY "Public can read generated songs"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'generated_songs');

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON songs(user_id);
CREATE INDEX IF NOT EXISTS idx_songs_status ON songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON songs(created_at);