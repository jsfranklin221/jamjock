/*
  # Initial Schema Setup for JamJock

  1. Tables
    - songs: Store song generation requests and results
    - analytics: Track key metrics and daily statistics

  2. Security
    - Public access for song creation
    - Protected access for analytics
    - Storage policies for voice samples
*/

-- Create songs table
CREATE TABLE IF NOT EXISTS public.songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  voice_sample_url text NOT NULL,
  preview_url text,
  full_song_url text,
  share_url text UNIQUE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  paid boolean NOT NULL DEFAULT false,
  stripe_session_id text,
  captcha_verified boolean NOT NULL DEFAULT false
);

-- Create analytics table
CREATE TABLE IF NOT EXISTS public.analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE NOT NULL DEFAULT CURRENT_DATE,
  voice_recordings_count integer DEFAULT 0,
  preview_generations_count integer DEFAULT 0,
  captcha_attempts_count integer DEFAULT 0,
  captcha_success_count integer DEFAULT 0,
  payment_attempts_count integer DEFAULT 0,
  payment_success_count integer DEFAULT 0,
  full_song_generations_count integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can create songs" ON public.songs;
  DROP POLICY IF EXISTS "Anyone can view shared songs" ON public.songs;
  DROP POLICY IF EXISTS "Only service role can modify analytics" ON public.analytics;
  DROP POLICY IF EXISTS "Anyone can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Songs policies
CREATE POLICY "Anyone can create songs"
  ON public.songs FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view shared songs"
  ON public.songs FOR SELECT
  TO public
  USING (share_url IS NOT NULL OR id IS NOT NULL);

-- Analytics policies
CREATE POLICY "Only service role can modify analytics"
  ON public.analytics
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create storage bucket for voice samples if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('voice_samples', 'voice_samples', false)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Storage policies (only create if they don't exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Anyone can upload voice samples' 
    AND tablename = 'objects'
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Anyone can upload voice samples"
      ON storage.objects FOR INSERT
      TO public
      WITH CHECK (bucket_id = 'voice_samples');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Anyone can read voice samples' 
    AND tablename = 'objects'
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Anyone can read voice samples"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = 'voice_samples');
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_songs_status ON public.songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON public.songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON public.songs(share_url);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON public.analytics(date);

-- Create function to increment analytics
CREATE OR REPLACE FUNCTION increment_analytics(
  metric text,
  increment integer DEFAULT 1
) RETURNS void AS $$
BEGIN
  INSERT INTO public.analytics (date)
  VALUES (CURRENT_DATE)
  ON CONFLICT (date) DO UPDATE
  SET
    voice_recordings_count = CASE 
      WHEN metric = 'voice_recordings' 
      THEN analytics.voice_recordings_count + increment 
      ELSE analytics.voice_recordings_count 
    END,
    preview_generations_count = CASE 
      WHEN metric = 'preview_generations' 
      THEN analytics.preview_generations_count + increment 
      ELSE analytics.preview_generations_count 
    END,
    captcha_attempts_count = CASE 
      WHEN metric = 'captcha_attempts' 
      THEN analytics.captcha_attempts_count + increment 
      ELSE analytics.captcha_attempts_count 
    END,
    captcha_success_count = CASE 
      WHEN metric = 'captcha_success' 
      THEN analytics.captcha_success_count + increment 
      ELSE analytics.captcha_success_count 
    END,
    payment_attempts_count = CASE 
      WHEN metric = 'payment_attempts' 
      THEN analytics.payment_attempts_count + increment 
      ELSE analytics.payment_attempts_count 
    END,
    payment_success_count = CASE 
      WHEN metric = 'payment_success' 
      THEN analytics.payment_success_count + increment 
      ELSE analytics.payment_success_count 
    END,
    full_song_generations_count = CASE 
      WHEN metric = 'full_song_generations' 
      THEN analytics.full_song_generations_count + increment 
      ELSE analytics.full_song_generations_count 
    END,
    updated_at = now()
  WHERE analytics.date = CURRENT_DATE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;