/*
  # Initial Schema Setup for JamJock

  1. Tables
    - users
    - songs
    - daily_stats
  
  2. Security
    - RLS policies
    - Storage buckets
    - Indexes
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  stripe_customer_id text
);

-- Create songs table
CREATE TABLE IF NOT EXISTS songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  title text NOT NULL,
  voice_sample_url text NOT NULL,
  preview_url text,
  full_song_url text,
  share_url text UNIQUE,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  paid boolean DEFAULT false,
  stripe_price_id text
);

-- Create daily_stats table
CREATE TABLE IF NOT EXISTS daily_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE NOT NULL DEFAULT CURRENT_DATE,
  generations integer DEFAULT 0,
  earnings numeric(10,2) DEFAULT 0,
  api_costs numeric(10,2) DEFAULT 0
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_stats ENABLE ROW LEVEL SECURITY;

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('voice_samples', 'voice_samples', false),
  ('generated_songs', 'generated_songs', true)
ON CONFLICT (id) DO NOTHING;

-- Users policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND policyname = 'Users can read own data'
  ) THEN
    CREATE POLICY "Users can read own data"
      ON users
      FOR SELECT
      TO authenticated
      USING (auth.uid() = id);
  END IF;
END $$;

-- Songs policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'songs' 
    AND policyname = 'Users can read own songs'
  ) THEN
    CREATE POLICY "Users can read own songs"
      ON songs
      FOR SELECT
      TO authenticated
      USING (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'songs' 
    AND policyname = 'Public can access shared songs'
  ) THEN
    CREATE POLICY "Public can access shared songs"
      ON songs
      FOR SELECT
      TO public
      USING (share_url IS NOT NULL);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'songs' 
    AND policyname = 'Public can create songs'
  ) THEN
    CREATE POLICY "Public can create songs"
      ON songs
      FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'songs' 
    AND policyname = 'Public can view paid songs'
  ) THEN
    CREATE POLICY "Public can view paid songs"
      ON songs
      FOR SELECT
      TO public
      USING (paid = true);
  END IF;
END $$;

-- Daily stats policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'daily_stats' 
    AND policyname = 'Only admins can access stats'
  ) THEN
    CREATE POLICY "Only admins can access stats"
      ON daily_stats
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM users
        WHERE users.id = auth.uid()
        AND users.is_admin = true
      ));
  END IF;
END $$;

-- Storage policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public can upload voice samples'
  ) THEN
    CREATE POLICY "Public can upload voice samples"
      ON storage.objects
      FOR INSERT
      TO public
      WITH CHECK (bucket_id = 'voice_samples');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public can read generated songs'
  ) THEN
    CREATE POLICY "Public can read generated songs"
      ON storage.objects
      FOR SELECT
      TO public
      USING (bucket_id = 'generated_songs');
  END IF;
END $$;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON songs(user_id);
CREATE INDEX IF NOT EXISTS idx_songs_status ON songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON songs(share_url);