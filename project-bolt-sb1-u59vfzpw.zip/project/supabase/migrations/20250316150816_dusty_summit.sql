/*
  # Fix Infinite Recursion in RLS Policies

  1. Changes
    - Simplify RLS policies to prevent circular references
    - Update policies for authenticated and public access
    - Fix policy logic for viewing songs

  2. Security
    - Maintain proper access controls
    - Ensure users can view their own songs
    - Allow public access to shared songs
*/

-- Drop existing policies to avoid conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view own songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can access songs" ON public.songs;
  DROP POLICY IF EXISTS "Anyone can create songs" ON public.songs;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create simplified policies without circular references
CREATE POLICY "Users can view own songs"
  ON public.songs
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    (paid = true AND share_url IS NOT NULL)
  );

CREATE POLICY "Public can access shared songs"
  ON public.songs
  FOR SELECT
  TO public
  USING (
    paid = true AND 
    share_url IS NOT NULL
  );

CREATE POLICY "Anyone can create songs"
  ON public.songs
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Ensure proper indexes exist
CREATE INDEX IF NOT EXISTS idx_songs_user_paid ON public.songs(user_id, paid);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON public.songs(share_url);