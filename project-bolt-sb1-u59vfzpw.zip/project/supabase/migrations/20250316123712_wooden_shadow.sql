/*
  # Add Stripe Payment Integration

  1. New Tables
    - transactions
      - id (uuid, primary key)
      - song_id (uuid, reference to songs)
      - amount (integer, in cents)
      - status (text: pending, completed, failed)
      - stripe_payment_intent_id (text)
      - created_at (timestamp)
      - updated_at (timestamp)

  2. Updates
    - Add stripe-related columns to songs table
    - Add payment-related analytics tracking
*/

-- Create transactions table
CREATE TABLE IF NOT EXISTS public.transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  song_id uuid REFERENCES public.songs(id) NOT NULL,
  amount integer NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  stripe_payment_intent_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_transactions_song_id ON public.transactions(song_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON public.transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_payment_intent ON public.transactions(stripe_payment_intent_id);

-- Create policies
CREATE POLICY "Public can create transactions"
  ON public.transactions
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can view own transactions"
  ON public.transactions
  FOR SELECT
  TO public
  USING (
    song_id IN (
      SELECT id FROM public.songs
      WHERE share_url IS NOT NULL OR id IS NOT NULL
    )
  );

-- Add trigger for updated_at
CREATE TRIGGER set_transactions_updated_at
  BEFORE UPDATE ON public.transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to handle successful payments
CREATE OR REPLACE FUNCTION handle_payment_success(
  p_payment_intent_id text,
  p_song_id uuid
) RETURNS void AS $$
BEGIN
  -- Update transaction status
  UPDATE public.transactions
  SET status = 'completed'
  WHERE stripe_payment_intent_id = p_payment_intent_id;

  -- Update song paid status
  UPDATE public.songs
  SET 
    paid = true,
    status = 'processing'
  WHERE id = p_song_id;

  -- Track analytics
  PERFORM increment_analytics('payment_success');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to handle failed payments
CREATE OR REPLACE FUNCTION handle_payment_failure(
  p_payment_intent_id text
) RETURNS void AS $$
BEGIN
  UPDATE public.transactions
  SET status = 'failed'
  WHERE stripe_payment_intent_id = p_payment_intent_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;