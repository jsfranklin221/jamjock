/*
  # Fix preview generation permissions

  1. Changes
    - Update RLS policies for songs table
    - Update storage policies for voice samples
    - Add policies for authenticated users
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can view songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can access shared songs" ON public.songs;
  DROP POLICY IF EXISTS "Users can view own songs" ON public.songs;
  DROP POLICY IF EXISTS "Anyone can create songs" ON public.songs;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Anyone can create songs"
  ON public.songs
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can view own songs"
  ON public.songs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Public can access songs"
  ON public.songs
  FOR SELECT
  TO public
  USING (id IS NOT NULL);

-- Update storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can upload voice samples" ON storage.objects;
  
  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'voice_samples');

  CREATE POLICY "Anyone can upload voice samples"
    ON storage.objects
    FOR INSERT
    TO public
    WITH CHECK (bucket_id = 'voice_samples');
END $$;