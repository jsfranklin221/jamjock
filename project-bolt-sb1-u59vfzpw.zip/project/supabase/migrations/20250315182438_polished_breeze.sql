/*
  # Update Schema for Public Access

  1. Changes
    - Add share_url to songs table
    - Make user_id optional
    - Update policies for public access
    - Remove authentication requirements

  2. Security
    - Enable public access with appropriate restrictions
    - Maintain data integrity with share URLs
*/

-- Add share_url to songs table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' 
    AND column_name = 'share_url'
  ) THEN
    ALTER TABLE songs ADD COLUMN share_url text;
    -- Add unique constraint only if it doesn't exist
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint 
      WHERE conname = 'songs_share_url_key'
    ) THEN
      ALTER TABLE songs ADD CONSTRAINT songs_share_url_key UNIQUE (share_url);
    END IF;
  END IF;
END $$;

-- Make user_id optional if it isn't already
DO $$ 
BEGIN
  ALTER TABLE songs ALTER COLUMN user_id DROP NOT NULL;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read own songs" ON songs;
  DROP POLICY IF EXISTS "Users can create songs" ON songs;
  DROP POLICY IF EXISTS "Public can view paid songs" ON songs;
  DROP POLICY IF EXISTS "Public can access shared songs" ON songs;
  DROP POLICY IF EXISTS "Public can create songs" ON songs;
  DROP POLICY IF EXISTS "Authenticated users can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can read generated songs" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies with checks for existence
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public can create songs' 
    AND tablename = 'songs'
  ) THEN
    CREATE POLICY "Public can create songs"
      ON songs
      FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public can access shared songs' 
    AND tablename = 'songs'
  ) THEN
    CREATE POLICY "Public can access shared songs"
      ON songs
      FOR SELECT
      TO public
      USING (share_url IS NOT NULL);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public can view paid songs' 
    AND tablename = 'songs'
  ) THEN
    CREATE POLICY "Public can view paid songs"
      ON songs
      FOR SELECT
      TO public
      USING (paid = true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public can upload voice samples' 
    AND schemaname = 'storage' 
    AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Public can upload voice samples"
      ON storage.objects
      FOR INSERT
      TO public
      WITH CHECK (bucket_id = 'voice_samples');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public can read generated songs' 
    AND schemaname = 'storage' 
    AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Public can read generated songs"
      ON storage.objects
      FOR SELECT
      TO public
      USING (bucket_id = 'generated_songs');
  END IF;
END $$;