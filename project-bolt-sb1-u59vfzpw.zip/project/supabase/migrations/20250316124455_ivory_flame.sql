/*
  # Update Schema for Stripe Payment Links

  1. Changes
    - Add stripe_payment_link_id to songs table
    - Drop and recreate payment success function
    - Add new index for payment links
*/

-- Add stripe_payment_link_id to songs table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'stripe_payment_link_id'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN stripe_payment_link_id text;
  END IF;
END $$;

-- Create index for payment link ID
CREATE INDEX IF NOT EXISTS idx_songs_payment_link ON public.songs(stripe_payment_link_id);

-- Drop existing payment success function first
DROP FUNCTION IF EXISTS handle_payment_success(text, uuid);

-- Create new payment success function
CREATE OR REPLACE FUNCTION handle_payment_success(
  p_payment_link_id text,
  p_song_id uuid
) RETURNS void AS $$
BEGIN
  -- Update song paid status
  UPDATE public.songs
  SET 
    paid = true,
    status = 'processing'
  WHERE id = p_song_id
    AND stripe_payment_link_id = p_payment_link_id;

  -- Track analytics
  PERFORM increment_analytics('payment_success');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;