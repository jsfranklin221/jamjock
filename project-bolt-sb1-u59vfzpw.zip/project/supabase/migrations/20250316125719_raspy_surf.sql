/*
  # Payment Flow Updates

  1. Changes
    - Add client_reference_id to songs table
    - Add webhook_processed flag to prevent duplicate processing
    - Update handle_payment_success function to generate share URL

  2. Security
    - Ensure proper RLS policies for payment processing
*/

-- Add new columns to songs table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'client_reference_id'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN client_reference_id text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'webhook_processed'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN webhook_processed boolean DEFAULT false;
  END IF;
END $$;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_songs_client_reference_id ON public.songs(client_reference_id);
CREATE INDEX IF NOT EXISTS idx_songs_webhook_processed ON public.songs(webhook_processed);

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS handle_payment_success(text, uuid);

-- Create updated payment success handler
CREATE OR REPLACE FUNCTION handle_payment_success(
  p_client_reference_id text,
  p_session_id text
) RETURNS void AS $$
DECLARE
  v_song_id uuid;
  v_share_url text;
BEGIN
  -- Get song ID from client reference
  SELECT id INTO v_song_id
  FROM public.songs
  WHERE client_reference_id = p_client_reference_id
    AND NOT webhook_processed;

  IF v_song_id IS NULL THEN
    RAISE EXCEPTION 'Song not found or already processed';
  END IF;

  -- Generate unique share URL
  v_share_url := concat('https://easyearn.app/song/', v_song_id);

  -- Update song record
  UPDATE public.songs
  SET 
    paid = true,
    status = 'processing',
    share_url = v_share_url,
    webhook_processed = true,
    stripe_session_id = p_session_id
  WHERE id = v_song_id;

  -- Track analytics
  PERFORM increment_analytics('payment_success');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;