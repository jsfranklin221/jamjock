/*
  # Initial Schema Setup for JamJock

  1. Tables
    - users (if not exists)
      - id (uuid, primary key)
      - email (text, unique)
      - is_admin (boolean)
      - created_at (timestamp)
    
    - songs (if not exists)
      - id (uuid, primary key)
      - user_id (uuid, foreign key)
      - original_title (text)
      - preview_url (text)
      - full_url (text)
      - status (text)
      - created_at (timestamp)
      - paid (boolean)
    
    - daily_stats (if not exists)
      - id (uuid, primary key)
      - date (date, unique)
      - generations (integer)
      - earnings (numeric)
      - api_costs (numeric)

  2. Security
    - Enable RLS on all tables
    - Add policies for user access
    - Add policies for admin access
*/

-- Users table and policies
DO $$ 
BEGIN
  -- Create users table if it doesn't exist
  CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text UNIQUE NOT NULL,
    is_admin boolean DEFAULT false,
    created_at timestamptz DEFAULT now()
  );

  -- Enable RLS
  ALTER TABLE users ENABLE ROW LEVEL SECURITY;

  -- Create policy if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Users can read own data'
  ) THEN
    CREATE POLICY "Users can read own data"
      ON users
      FOR SELECT
      TO authenticated
      USING (auth.uid() = id);
  END IF;
END $$;

-- Songs table and policies
DO $$ 
BEGIN
  -- Create songs table if it doesn't exist
  CREATE TABLE IF NOT EXISTS songs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES users(id),
    original_title text NOT NULL,
    preview_url text,
    full_url text,
    status text NOT NULL DEFAULT 'processing',
    created_at timestamptz DEFAULT now(),
    paid boolean DEFAULT false
  );

  -- Enable RLS
  ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

  -- Create policies if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Users can read own songs'
  ) THEN
    CREATE POLICY "Users can read own songs"
      ON songs
      FOR SELECT
      TO authenticated
      USING (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Users can create songs'
  ) THEN
    CREATE POLICY "Users can create songs"
      ON songs
      FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- Daily Stats table and policies
DO $$ 
BEGIN
  -- Create daily_stats table if it doesn't exist
  CREATE TABLE IF NOT EXISTS daily_stats (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    date date UNIQUE NOT NULL DEFAULT CURRENT_DATE,
    generations integer DEFAULT 0,
    earnings numeric(10,2) DEFAULT 0,
    api_costs numeric(10,2) DEFAULT 0
  );

  -- Enable RLS
  ALTER TABLE daily_stats ENABLE ROW LEVEL SECURITY;

  -- Create policy if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Only admins can access stats'
  ) THEN
    CREATE POLICY "Only admins can access stats"
      ON daily_stats
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM users
        WHERE users.id = auth.uid()
        AND users.is_admin = true
      ));
  END IF;
END $$;

-- Create indexes if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_daily_stats_date'
  ) THEN
    CREATE INDEX idx_daily_stats_date ON daily_stats(date);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_songs_user_id'
  ) THEN
    CREATE INDEX idx_songs_user_id ON songs(user_id);
  END IF;
END $$;