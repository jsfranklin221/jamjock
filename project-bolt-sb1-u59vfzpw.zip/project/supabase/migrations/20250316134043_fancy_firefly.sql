/*
  # Update RLS Policies for Public Song Access

  1. Changes
    - Add policy for public song access
    - Update storage policies for public access to voice samples
    - Remove authentication requirements for song viewing

  2. Security
    - Maintain data integrity while allowing public access
    - Ensure proper access controls for sensitive operations
*/

-- Update songs table policies
DO $$ 
BEGIN
  -- Drop existing policies first
  DROP POLICY IF EXISTS "Anyone can view songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  DROP POLICY IF EXISTS "Public can access shared songs" ON public.songs;

  -- Create new public access policy
  CREATE POLICY "Anyone can view songs"
    ON public.songs
    FOR SELECT
    TO public
    USING (true);
END $$;

-- Update storage policies for voice samples
DO $$
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;
  
  -- Create new public access policy
  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'voice_samples');
END $$;