/*
  # Fix Backing Tracks Storage Policies

  1. Changes
    - Make backing_tracks bucket public
    - Add proper RLS policies for public access
    - Fix policy conflicts

  2. Security
    - Allow public read access to backing tracks
    - Allow public upload access to backing tracks
    - Maintain data integrity
*/

-- Ensure backing_tracks bucket exists and is public
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('backing_tracks', 'backing_tracks', true)
  ON CONFLICT (id) DO UPDATE
  SET public = true;
END $$;

-- Drop existing policies to avoid conflicts
DO $$
BEGIN
  DROP POLICY IF EXISTS "Public can read backing tracks" ON storage.objects;
  DROP POLICY IF EXISTS "Public can upload backing tracks" ON storage.objects;
  DROP POLICY IF EXISTS "Service role can upload backing tracks" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for public access
CREATE POLICY "Public can read backing tracks"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'backing_tracks');

CREATE POLICY "Public can upload backing tracks"
  ON storage.objects
  FOR INSERT
  TO public
  WITH CHECK (bucket_id = 'backing_tracks');

-- Add backing_track_url to songs table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'backing_track_url'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN backing_track_url text;
  END IF;
END $$;

-- Create index for backing track URL if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_songs_backing_track ON public.songs(backing_track_url);