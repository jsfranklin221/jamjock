/*
  # Initial Schema Setup for JockJam

  1. New Tables
    - `songs`
      - `id` (uuid, primary key): Unique identifier for each song
      - `user_id` (uuid): Reference to the authenticated user
      - `user_name` (text): Name of the user who created the song
      - `voice_sample_url` (text): URL to the uploaded voice sample
      - `preview_url` (text): URL to the 10-second preview
      - `full_song_url` (text): URL to the complete 30-second song
      - `status` (song_status): Current status of the song
      - `created_at` (timestamptz): When the song was created
      - `paid` (boolean): Whether the song has been paid for

  2. Storage
    - `voice_samples`: Private bucket for user voice recordings
    - `generated_songs`: Public bucket for generated songs

  3. Security
    - RLS enabled on songs table
    - Policies for public access to paid songs
    - Policies for authenticated users to create songs
    - Storage policies for voice samples and generated songs
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public can view paid songs" ON songs;
  DROP POLICY IF EXISTS "Users can create songs" ON songs;
  DROP POLICY IF EXISTS "Authenticated users can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Public can read generated songs" ON storage.objects;
EXCEPTION
  WHEN undefined_table THEN
    NULL;
END $$;

-- Create an enum for song status
DO $$ 
BEGIN
  CREATE TYPE song_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
  );
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

-- Create songs table
CREATE TABLE IF NOT EXISTS songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  user_name text NOT NULL,
  voice_sample_url text NOT NULL,
  preview_url text,
  full_song_url text,
  status song_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  paid boolean DEFAULT false
);

-- Enable RLS
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- Create policies after table exists
CREATE POLICY "Public can view paid songs"
  ON songs
  FOR SELECT
  USING (paid = true);

CREATE POLICY "Users can create songs"
  ON songs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create storage buckets
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES 
    ('voice_samples', 'voice_samples', false),
    ('generated_songs', 'generated_songs', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Set up storage policies
CREATE POLICY "Authenticated users can upload voice samples"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'voice_samples');

CREATE POLICY "Public can read generated songs"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'generated_songs');

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_songs_user_id ON songs (user_id);
CREATE INDEX IF NOT EXISTS idx_songs_status ON songs (status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON songs (created_at);