-- Create backing_tracks bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('backing_tracks', 'backing_tracks', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Add backing_track_url to songs table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'backing_track_url'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN backing_track_url text;
  END IF;
END $$;

-- Create index for backing track URL
CREATE INDEX IF NOT EXISTS idx_songs_backing_track ON public.songs(backing_track_url);

-- Create storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Public can read backing tracks" ON storage.objects;
  DROP POLICY IF EXISTS "Service role can upload backing tracks" ON storage.objects;

  CREATE POLICY "Public can read backing tracks"
    ON storage.objects
    FOR SELECT
    TO public
    USING (bucket_id = 'backing_tracks');

  CREATE POLICY "Service role can upload backing tracks"
    ON storage.objects
    FOR INSERT
    TO service_role
    WITH CHECK (bucket_id = 'backing_tracks');
END $$;