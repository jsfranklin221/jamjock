/*
  # Clean up Database Schema

  1. Changes
    - Drop unnecessary tables (amazon_products, notification_settings, etc.)
    - Keep only required tables for JamJock (songs, analytics)
    - Ensure proper constraints and indexes remain

  2. Security
    - Maintain RLS policies for remaining tables
    - Keep storage policies intact
*/

-- Drop unnecessary tables
DROP TABLE IF EXISTS public.amazon_products CASCADE;
DROP TABLE IF EXISTS public.notification_settings CASCADE;
DROP TABLE IF EXISTS public.notification_logs CASCADE;
DROP TABLE IF EXISTS public.notification_templates CASCADE;
DROP TABLE IF EXISTS public.usage_stats CASCADE;
DROP TABLE IF EXISTS public.integration_accounts CASCADE;
DROP TABLE IF EXISTS public.system_logs CASCADE;
DROP TABLE IF EXISTS public.platform_settings CASCADE;
DROP TABLE IF EXISTS public.integration_credentials CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;
DROP TABLE IF EXISTS public.payments CASCADE;
DROP TABLE IF EXISTS public.daily_stats CASCADE;

-- Drop any related types that might exist
DROP TYPE IF EXISTS public.song_status CASCADE;

-- Verify our core tables exist
DO $$ 
BEGIN
  -- Ensure songs table exists with correct schema
  CREATE TABLE IF NOT EXISTS public.songs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    voice_sample_url text NOT NULL,
    preview_url text,
    full_song_url text,
    share_url text UNIQUE,
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    created_at timestamptz NOT NULL DEFAULT now(),
    paid boolean NOT NULL DEFAULT false,
    stripe_session_id text,
    captcha_verified boolean NOT NULL DEFAULT false
  );

  -- Ensure analytics table exists with correct schema
  CREATE TABLE IF NOT EXISTS public.analytics (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    date date UNIQUE NOT NULL DEFAULT CURRENT_DATE,
    voice_recordings_count integer DEFAULT 0,
    preview_generations_count integer DEFAULT 0,
    captcha_attempts_count integer DEFAULT 0,
    captcha_success_count integer DEFAULT 0,
    payment_attempts_count integer DEFAULT 0,
    payment_success_count integer DEFAULT 0,
    full_song_generations_count integer DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
  );
END $$;

-- Ensure RLS is enabled
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics ENABLE ROW LEVEL SECURITY;

-- Recreate policies
DO $$ 
BEGIN
  -- Songs policies
  DROP POLICY IF EXISTS "Anyone can create songs" ON public.songs;
  DROP POLICY IF EXISTS "Anyone can view shared songs" ON public.songs;
  
  CREATE POLICY "Anyone can create songs"
    ON public.songs FOR INSERT
    TO public
    WITH CHECK (true);

  CREATE POLICY "Anyone can view shared songs"
    ON public.songs FOR SELECT
    TO public
    USING (share_url IS NOT NULL OR id IS NOT NULL);

  -- Analytics policies
  DROP POLICY IF EXISTS "Only service role can modify analytics" ON public.analytics;
  
  CREATE POLICY "Only service role can modify analytics"
    ON public.analytics
    TO service_role
    USING (true)
    WITH CHECK (true);
END $$;

-- Ensure indexes exist
CREATE INDEX IF NOT EXISTS idx_songs_status ON public.songs(status);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON public.songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_share_url ON public.songs(share_url);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON public.analytics(date);

-- Verify storage bucket exists
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('voice_samples', 'voice_samples', false)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Ensure storage policies exist
DO $$
BEGIN
  -- Drop existing policies first
  DROP POLICY IF EXISTS "Anyone can upload voice samples" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can read voice samples" ON storage.objects;

  -- Recreate policies
  CREATE POLICY "Anyone can upload voice samples"
    ON storage.objects FOR INSERT
    TO public
    WITH CHECK (bucket_id = 'voice_samples');

  CREATE POLICY "Anyone can read voice samples"
    ON storage.objects FOR SELECT
    TO public
    USING (bucket_id = 'voice_samples');
END $$;