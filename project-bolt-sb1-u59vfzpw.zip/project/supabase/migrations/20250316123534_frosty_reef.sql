/*
  # Update Schema for JamJock

  1. Changes
    - Add title column to songs table
    - Add stripe_price_id column for payment tracking
    - Add update_at trigger for analytics
    - Add function to track analytics metrics

  2. Security
    - Add policy for viewing completed songs
    - Add policy for public preview access
*/

-- Add title column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'title'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN title text NOT NULL;
  END IF;
END $$;

-- Add stripe_price_id if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'songs' AND column_name = 'stripe_price_id'
  ) THEN
    ALTER TABLE public.songs ADD COLUMN stripe_price_id text;
  END IF;
END $$;

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger to analytics table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'set_analytics_updated_at'
  ) THEN
    CREATE TRIGGER set_analytics_updated_at
      BEFORE UPDATE ON public.analytics
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Add additional policies for songs
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public can view completed songs" ON public.songs;
  CREATE POLICY "Public can view completed songs"
    ON public.songs
    FOR SELECT
    TO public
    USING (status = 'completed');

  DROP POLICY IF EXISTS "Public can access previews" ON public.songs;
  CREATE POLICY "Public can access previews"
    ON public.songs
    FOR SELECT
    TO public
    USING (preview_url IS NOT NULL);
END $$;

-- Function to track song generation metrics
CREATE OR REPLACE FUNCTION track_song_generation(
  p_song_id uuid,
  p_metric text
) RETURNS void AS $$
BEGIN
  -- Update analytics
  PERFORM increment_analytics(p_metric);
  
  -- Update song status based on metric
  UPDATE public.songs
  SET status = CASE 
    WHEN p_metric = 'preview_generations' THEN 'processing'
    WHEN p_metric = 'full_song_generations' THEN 'completed'
    ELSE status
  END
  WHERE id = p_song_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;